/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.Services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.ui.events.ActionListener;
import com.mycompany.Models.stat_cours;

import com.mycompany.Utils.Statics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author user
 */
public class stat_cour_Service {
    public ArrayList<stat_cours> stat_cours;
    public static stat_cour_Service instance = null;
    public boolean resultOK;
    private ConnectionRequest req;
     public stat_cour_Service() {
        req = new ConnectionRequest();
    }

    public static stat_cour_Service getInstance() {
        if (instance == null) {
            instance = new stat_cour_Service();
        }
        return instance;
    }
        public ArrayList<stat_cours> parsstat_cours(String jsonText) {
        try {
            stat_cours = new ArrayList<>();
            JSONParser j = new JSONParser();
            Map<String, Object> ReclamationListJson = j.parseJSON(new CharArrayReader(jsonText.toCharArray()));

            List<Map<String, Object>> list = (List<Map<String, Object>>) ReclamationListJson.get("root");

            for (Map<String, Object> obj : list) {
                stat_cours s = new stat_cours();

                float nbr = Float.parseFloat(obj.get("nbr").toString());
                s.setNbr((int) nbr);

             

          
                s.setTitre(obj.get("titre").toString());
           
               
        
         
              
                
                // questionnaire q =new questionnaire();
                // q.setDescription_cat_qst((String) map.get("description_cat_qst"));
             
                stat_cours.add(s);
            }

        } catch (IOException ex) {
            System.out.println("Exception in parsing reclamations ");
        }

        return stat_cours;
    }

    public ArrayList<stat_cours> findAll() {
        String url = Statics.BASE_URL + "cours/StatMobile";
        req.setUrl(url);
        req.setPost(false);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                stat_cours = parsstat_cours(new String(req.getResponseData()));
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return stat_cours;
    }

}
