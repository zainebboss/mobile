/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.Services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.ui.events.ActionListener;
import com.mycompany.Models.Cours;
import com.mycompany.Utils.Statics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author user
 */
public class Cours_Service {
      public ArrayList<Cours> Cours;
    public static Cours_Service instance = null;
    public boolean resultOK;
    private ConnectionRequest req;
     public Cours_Service() {
        req = new ConnectionRequest();
    }

    public static Cours_Service getInstance() {
        if (instance == null) {
            instance = new Cours_Service();
        }
        return instance;
    }
        public ArrayList<Cours> parseCours(String jsonText) {
        try {
            Cours = new ArrayList<>();
            JSONParser j = new JSONParser();
            Map<String, Object> ReclamationListJson = j.parseJSON(new CharArrayReader(jsonText.toCharArray()));

            List<Map<String, Object>> list = (List<Map<String, Object>>) ReclamationListJson.get("root");

            for (Map<String, Object> obj : list) {
                Cours Cour = new Cours();

                float id = Float.parseFloat(obj.get("id").toString());
                Cour.setId((int) id);

                float nbr_qst = Float.parseFloat(obj.get("formationId").toString());
                Cour.setFormationid((int) nbr_qst);

                Cour.setDescription(obj.get("descriptionCat").toString());
                Cour.setTitre(obj.get("titre").toString());
              
                if(obj.get("favoris").toString().equals("true"))
                {
                        Cour.setFavoris(true);
                }
                else
                {
                     Cour.setFavoris(false);
                }
                      
        
         
              
                
                // questionnaire q =new questionnaire();
                // q.setDescription_cat_qst((String) map.get("description_cat_qst"));
             
                Cours.add(Cour);
            }

        } catch (IOException ex) {
            System.out.println("Exception in parsing reclamations ");
        }

        return Cours;
    }

    public ArrayList<Cours> findAll() {
        String url = Statics.BASE_URL + "cours/CoursMobile";
        req.setUrl(url);
        req.setPost(false);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                Cours = parseCours(new String(req.getResponseData()));
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return Cours;
    }
public void add_favouris(int id) {
        String url = Statics.BASE_URL + "cours/CoursMobile_Add_Favoris/"+id;
        req.setUrl(url);
        req.setPost(false);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
               // Cours = parseCours(new String(req.getResponseData()));
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
     
    }
public void delete_favouris(int id) {
        String url = Statics.BASE_URL + "cours/CoursMobile_Delete_Favoris/"+id;
        req.setUrl(url);
        req.setPost(false);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
               // Cours = parseCours(new String(req.getResponseData()));
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
     
    }
}
