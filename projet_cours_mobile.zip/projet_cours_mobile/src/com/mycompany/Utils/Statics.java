
package com.mycompany.Utils;
public class Statics {
    public static final String BASE_URL="http://127.0.0.1:8000/";
}
