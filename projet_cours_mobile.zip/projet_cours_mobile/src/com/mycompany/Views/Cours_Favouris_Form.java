/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.Views;

import com.codename1.components.InfiniteProgress;
import com.codename1.components.MultiButton;
import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.mycompany.Models.Cours;
import com.mycompany.Models.Formation;
import com.mycompany.Services.Cours_Service;
import com.mycompany.Services.Formation_Service;
import com.mycompany.myapp.MyApplication;

/**
 *
 * @author user
 */
public class Cours_Favouris_Form extends Form {

    Resources theme = UIManager.initFirstTheme("/theme");
    public Cours_Favouris_Form(Form previous)
    {
         super("Cours Favouris",BoxLayout.y());
          this.add(new InfiniteProgress());
        Display.getInstance().scheduleBackgroundTask(() -> {
            // this will take a while...

            Display.getInstance().callSerially(() -> {
                this.removeAll();
          
             for (Cours c : new Cours_Service().findAll()) {
                 if(c.isFavoris())
                 {
                      this.add(addItem_Cours(c));
                 }

           

        }
               this.revalidate();
            });
        });

        this.getToolbar().addSearchCommand(e -> {
            String text = (String) e.getSource();
            if (text == null || text.length() == 0) {
                // clear search
                for (Component cmp : this.getContentPane()) {
                    cmp.setHidden(false);
                    cmp.setVisible(true);
                }
                this.getContentPane().animateLayout(150);
            } else {
                text = text.toLowerCase();
                for (Component cmp : this.getContentPane()) {
                    MultiButton mb = (MultiButton) cmp;
                    String line1 = mb.getTextLine1();
                    String line2 = mb.getTextLine2();
                    mb.setUIIDLine1("libC");
                    mb.setUIIDLine2("btn");
                    boolean show = line1 != null && line1.toLowerCase().indexOf(text) > -1
                            || line2 != null && line2.toLowerCase().indexOf(text) > -1;
                    mb.setHidden(!show);
                    mb.setVisible(show);
                }
                this.getContentPane().animateLayout(150);
            }
        }, 4);
               this.getToolbar().addCommandToOverflowMenu("back", null, ev -> {
           new MyApplication().start();
        });
    }
    
     public MultiButton  addItem_Cours(Cours c) {
 MultiButton m = new MultiButton();
        m.setTextLine1(c.getTitre());
        m.setTextLine2(c.getDescription());
     
    
          
        m.setEmblem(theme.getImage("round.png"));
      
        m.setIcon(theme.getImage("cours.png"));
        m.addActionListener(e -> {

            Form f2 = new Form("Detail",BoxLayout.y());
           
            Button btn = new Button("remove");
           f2.add("Titre :").add(c.getTitre()).add("Categorie : ").add(c.getDescription()).add("Formation : ");
        
            for (Formation f : new Formation_Service().findAll()) {
                
                if(c.getFormationid() == f.getId())
                {
                    f2.add(f.getTitre());
                }
                
            }
            
                btn.addActionListener(ew -> {
          Cours_Service cs=      new Cours_Service();
          
          cs.delete_favouris(c.getId());
                 Dialog.show("Supprime de favouris", "Supprime", "OK", null);
                       new MyApplication().start();
                });
         
           
                     f2.getToolbar().addCommandToOverflowMenu("back", null, ev -> {
           new MyApplication().start();
        });   
            f2.add(btn); 
 f2.show();
        
        
           
                
          
 f2.show();
        });
      

   
        return m;

    }
     
}
