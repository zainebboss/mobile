/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.Models;

/**
 *
 * @author user
 */
public class stat_cours {
    private int nbr;
    private String titre;

    public stat_cours() {
    }

    public stat_cours(int nbr, String titre) {
        this.nbr = nbr;
        this.titre = titre;
    }

    public int getNbr() {
        return nbr;
    }

    public void setNbr(int nbr) {
        this.nbr = nbr;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }
    
}
